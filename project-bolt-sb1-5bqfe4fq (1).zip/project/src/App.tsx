import React from 'react';
import { CareerRecommender } from './components/CareerRecommender';

function App() {
  return <CareerRecommender />;
}

export default App;